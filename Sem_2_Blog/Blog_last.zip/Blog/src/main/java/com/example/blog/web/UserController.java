package com.example.blog.web;

import com.example.blog.models.Post;
import com.example.blog.models.User;
import com.example.blog.repositories.UserRepository;
import com.example.blog.services.PostService;
import com.example.blog.services.UserService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
/*
{
    "login":"5",
    "firstName": "test5",
    "lastName":"1",
    "middleName":"1",
    "birthday":"2023-09-03"

}
 */
@RestController
public class UserController {

    @Autowired
    UserService userService;

    @Autowired
    PostService postService;
    @PostMapping("/addUser")
    public ResponseEntity<?> addUser(@RequestBody User user){
        // получает юзера и добавляет его в БД, если таких юзеров еще нет
        if(userService.existsByLogin(user.getLogin())){
            return new ResponseEntity<>("User already exist", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        Long id = userService.addUser(user);
        // возвращаем id созданного юзера
        return new ResponseEntity<>("User created, id: "+ id,HttpStatus.OK);
    }

    @GetMapping("/getUsers")
    public ResponseEntity<?> getUsers(){
        // возвращает всею юзеров из БД
        List<User> users = userService.getUsers();
        if(users.isEmpty()){
            return new ResponseEntity<>("No users yet",HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(users,HttpStatus.OK);
    }

    @DeleteMapping("/delUser")
    @Transactional
    public ResponseEntity<?> delUser(@RequestParam (name="login") String login){
        // удаляет юзера по логину, если он существует
        if(userService.existsByLogin(login)){
            userService.delUser(login);
            return new ResponseEntity<>("User deleted",HttpStatus.OK);
        }
        return new ResponseEntity<>("No users yet",HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @PutMapping ("/updateUser")
    public ResponseEntity<?> updateUser(@RequestBody User user){
        // обновляет информацию о юзере, если он существует
        if(userService.existsByLogin(user.getLogin())){
            Date updateTime = new Date();
            Long id = userService.updateUser(user.getId(), user.getLogin(), user.getFirstName(), user.getLastName(), user.getMiddleName(), user.getBirthday(),user.getcreateTime(),updateTime);
                return new ResponseEntity<>("User " + id + "updated",HttpStatus.OK);
        }
        return new ResponseEntity<>("No users",HttpStatus.INTERNAL_SERVER_ERROR);
    }


}
