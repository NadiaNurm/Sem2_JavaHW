package com.example.blog.repositories;

import com.example.blog.models.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserRepository extends JpaRepository<User,Long> {

    public boolean existsByLogin(String login);
    public User findUserByLogin(String login);
    public void deleteByLogin(String login);

}