package com.example.blog.web;

import com.example.blog.models.Category;
import com.example.blog.models.Post;
import com.example.blog.models.User;
import com.example.blog.services.CategoryService;
import com.example.blog.services.PostService;
import com.example.blog.services.UserService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@RestController
public class PostController {
    @Autowired
    PostService postService;
    @Autowired
    UserService userService;
    @Autowired
    CategoryService categoryService;

    @PostMapping("/addPost")
    public ResponseEntity<?> addPost(@RequestBody Post post, @RequestParam (name="id_user") Long id_user, @RequestParam (name="category_id_list",required = false) Long[] category_id_list) {
        // ппередаем пост, который хотим добавить; id_user для юзера, которому принадлежит пост; список из id категорий;

        if(id_user == null){
            // пост должен принадлежать какому-то конкретному юзеру, поэтому при создании поста мы должны передать параметр для идентификации (id_user)
            return new ResponseEntity<>("No id_user",HttpStatus.INTERNAL_SERVER_ERROR);
        }
        if(postService.existsByName(post.getName())){
            // проверяем, нет ли такого поста с таким именем
            return new ResponseEntity<>("Post already exist",HttpStatus.INTERNAL_SERVER_ERROR);
        }

        // получаем Id созданного поста
        Long  id_post = postService.addPost(post);
        // получаем юзера, которому должен принадлежать пост
        User user = userService.findByID(id_user);
        // получаем наш пост по Id, который мы получили при создании
        Post post1 = postService.findPostByID(id_post);
        // получаем список постов нужного юзера и добавляем пост
        user.getPosts().add(post1);
        userService.addUser(user);

        // получаем список категорий по id из списка,который мы передали в параметрах
        List<Category> categories = new ArrayList<>();
        for (Long id_cat : category_id_list) {
            Category cat = categoryService.findCatById(id_cat);
            categories.add(cat);
        }
        // добавляем список категорий и добавляем пост
        post1.setCategoryList(categories);
        postService.addPost(post1);

        // получаем список постов для каждой категории и добавляем в него наш пост
        for (Category cat : categories) {
            cat.getPostList().add(post1);
            categoryService.addCategory(cat);
        }
        // возвращаем id созданного поста
        return new ResponseEntity<>("Post created, id: " + id_post,HttpStatus.OK);
    }

    @GetMapping("/getPosts")
    public ResponseEntity<?> getPosts(){
        // возвращаем все посты из БД
        List<Post> posts=postService.getPosts();
        if(posts.isEmpty()){
            return new ResponseEntity<>("No posts yet",HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(posts,HttpStatus.OK);
    }
    @DeleteMapping("/delPost")
    @Transactional
    public ResponseEntity<?> delPost(@RequestParam (name="name") String name){
        // удаляем посты из БД по имени поста, если он существует
        if(postService.existsByName(name)){
            postService.delPost(name);
            return new ResponseEntity<>("Post deleted",HttpStatus.OK);
        }
        return new ResponseEntity<>("No posts yet",HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @PutMapping("/updatePost")
    public ResponseEntity<?> updatePost(@RequestBody Post post){
        // обновляет информацию о посте, если он существует
        if(postService.existsByName(post.getName())){
            Date updateTime = new Date();
            Long id = postService.updatePost(post.getId(),post.getName(),post.getAbout(),post.getCategoryList(),post.getCreateTime(),updateTime);
            return new ResponseEntity<>("Post " + id + "updated",HttpStatus.OK);
        }
        return new ResponseEntity<>("No posts yet",HttpStatus.INTERNAL_SERVER_ERROR);
    }



}
