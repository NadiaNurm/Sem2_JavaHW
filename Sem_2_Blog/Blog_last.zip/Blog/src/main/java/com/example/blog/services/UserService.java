package com.example.blog.services;

import com.example.blog.models.User;
import com.example.blog.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class UserService {
  @Autowired
  UserRepository userRepository;

  public Long addUser(User user){
      // Функция, которая добавляет юзера в базу данных и возвращает Id созданного юзера
      user.setcreateTime(new Date());
      return userRepository.save(user).getId();
  }

  public boolean existsByLogin(String login){
      // Функция, которая проверяет, существует ли юзер по логину
      return userRepository.existsByLogin(login);
  }

  public List<User> getUsers(){
      // Функция, которая возвращает всех юзеров из БД
      return userRepository.findAll();
  }

  public  User getUser(String login){
      // Функция, которая возвращает юзера по логину
      return userRepository.findUserByLogin(login);
  }
  public void delUser(String login){
      // Функция, которая удаляет юзера по логину
      userRepository.deleteByLogin(login);
  }

  public Long updateUser(Long id, String login, String firstName, String lastName, String middleName, Date birthday, Date createTime, Date updateTime){
      // Функция, которая обновляет информацию о юзере
      User user = userRepository.findUserByLogin(login);
      user.setId(id);
      user.setLogin(login);
      user.setFirstName(firstName);
      user.setLastName(lastName);
      user.setMiddleName(middleName);
      user.setBirthday(birthday);
      user.setcreateTime(createTime);
      user.setupdateTime(updateTime);
      User updated_user = userRepository.save(user);
      return updated_user.getId();
  }

    public User findByID(Long id){
        // Функция, которая возвращает юзера по id
      return userRepository.findById(id).get();
    }
}
