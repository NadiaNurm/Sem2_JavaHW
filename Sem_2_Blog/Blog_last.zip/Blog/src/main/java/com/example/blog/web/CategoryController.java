package com.example.blog.web;

import com.example.blog.models.Category;
import com.example.blog.models.Post;
import com.example.blog.models.User;
import com.example.blog.services.CategoryService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@RestController
public class CategoryController {
    @Autowired
    CategoryService categoryService;
    @PostMapping("/addCategory")
    public ResponseEntity<?> addCategory(@RequestBody Category category){
        // получает категорию и добавляет ее в БД, если такой категории еще нет
        if(categoryService.existsByName(category.getName())){
            return new ResponseEntity<>("Category already exist",HttpStatus.INTERNAL_SERVER_ERROR);
        }
        Long id_cat = categoryService.addCategory(category);
        return new ResponseEntity<>("Category created, id: " + id_cat, HttpStatus.OK);
    }

    @DeleteMapping("/delCategory")
    @Transactional
    public ResponseEntity<?> delCategory(@RequestParam(name="name") String name){
        // удаляем категорию из БД по имени, если она существует
        if(categoryService.existsByName(name)){
            categoryService.delCategory(name);
            return new ResponseEntity<>("Category deleted",HttpStatus.OK);
        }
        return new ResponseEntity<>("No such category",HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @GetMapping("/getCategories")
    public ResponseEntity<?> getCategories(){
        // возвращаем все категории из БД
        List<Category> categories = categoryService.getCategories();
        if (categories.isEmpty()){
            return new ResponseEntity<>("No categories yet",HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(categories,HttpStatus.OK);
    }

    @PutMapping("/udateCategory")
    public ResponseEntity<?> updateCategory(@RequestBody Category category){
        // обновляет информацию о категории, если она существует
        if(categoryService.existsByName(category.getName())){
            Long id = categoryService.updateCategory(category);
            return new ResponseEntity<>("Category " + id + "updated",HttpStatus.OK);
        }
        return new ResponseEntity<>("No such category",HttpStatus.INTERNAL_SERVER_ERROR);
    }


}
