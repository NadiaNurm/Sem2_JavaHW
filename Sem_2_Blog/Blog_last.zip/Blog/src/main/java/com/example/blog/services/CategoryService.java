package com.example.blog.services;

import com.example.blog.models.Category;
import com.example.blog.repositories.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class CategoryService {
    @Autowired
    CategoryRepository categoryRepository;

    public Category findCatById(Long id){
        // Функция, которая возвращает категорию по id
        return categoryRepository.findById(id).get();
    }

    public Long addCategory(Category category){
        // Функция, которая добавляет категорию в базу данных и возвращает Id
        category.setCreateTime(new Date());
        return categoryRepository.save(category).getId();
    }

    public boolean existsByName(String name){
        // Функция, которая проверяет, существует ли категория по имени
        return categoryRepository.existsByName(name);
    }
    public void delCategory(String name){
        // Функция, которая удаляет категорию по имени
        categoryRepository.deleteByName(name);
    }

    public List<Category> getCategories(){
        // Функция, которая возвращает все категории из БД
        return categoryRepository.findAll();
    }
    public Long updateCategory(Category category){
        // Функция, которая обновляет информацию о категории
        category.setUpdateTime(new Date());
        return categoryRepository.save(category).getId();
    }



}
