package com.example.blog.models;


import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

import java.util.Date;
import java.util.List;
import java.util.Set;

/*
Пользователь имеет следующие атрибуты:
-Уникальный идентификатор
-Логин
-Фамилия
-Имя
-Отчество
-Дата рождения
 */

@Entity
public class User {
    // генерация ID по умолчанию
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String login;
    private String firstName;
    private String lastName;
    private String middleName;
    private Date birthday;
    private Date createTime;
    private Date updateTime;

    //OneToMany – один ко многим
   @JsonIgnore
   @OneToMany()
   private List<Post> posts;

    public User(String firstName, String lastName, String middleName, Date birthday, List<Post> posts) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.middleName = middleName;
        this.birthday = birthday;
        this.posts = posts;
    }
    public User(String login, String firstName, String lastName, String middleName, Date birthday,Date createTime) {
        this.login = login;
        this.firstName = firstName;
        this.lastName = lastName;
        this.middleName = middleName;
        this.birthday = birthday;
        this.createTime = createTime;
    }
    public User(String login, String firstName, String lastName, String middleName, Date birthday,Date createTime,Date updateTime) {
        this.login = login;
        this.firstName = firstName;
        this.lastName = lastName;
        this.middleName = middleName;
        this.birthday = birthday;
        this.createTime = createTime;
        this.updateTime = updateTime;
    }

    public String getLogin() {
        return login;
    }
//
    public void setLogin(String login) {
        this.login = login;
    }
//
    public Date getcreateTime() {
        return createTime;
    }
//
    public void setcreateTime(Date createTime) {
        this.createTime = createTime;
    }
//
    public Date getupdateTime() {
        return updateTime;
    }
//
    public void setupdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
//
    public User() {
    }

    public List<Post> getPosts() {
        return posts;
    }
//
    public void setPosts(List<Post> posts) {

        this.posts = posts;
 }

    public Long getId() {
        return id;
    }

  public void setId(Long id) {
      this.id = id;
  }

  public String getFirstName() {
      return firstName;
  }

  public void setFirstName(String firstName) {
      this.firstName = firstName;
  }

  public String getLastName() {
      return lastName;
  }

  public void setLastName(String lastName) {
      this.lastName = lastName;
  }

  public String getMiddleName() {
      return middleName;
  }

  public void setMiddleName(String middleName) {
      this.middleName = middleName;
  }

  public Date getBirthday() {
        return birthday;
    }

  public void setBirthday(Date birthday) {
      this.birthday = birthday;
  }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", login='" + login + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", middleName='" + middleName + '\'' +
                ", birthday=" + birthday +
                ", createTime=" + createTime +
                ", updateTime=" + updateTime +
                ", posts=" + posts +
                '}';
    }
}
