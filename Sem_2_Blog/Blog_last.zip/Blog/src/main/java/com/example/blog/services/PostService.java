package com.example.blog.services;

import com.example.blog.models.Category;
import com.example.blog.models.Post;
import com.example.blog.models.User;
import com.example.blog.repositories.PostRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class PostService {
    @Autowired
    PostRepository postRepository;
    public Long addPost(Post post){
        // Функция, которая добавляет пост в базу данных и возвращает Id созданного поста
        post.setCreateTime(new Date());
        return postRepository.save(post).getId();
    }

    public boolean existsByName(String name){
        // Функция, которая проверяет, существует ли пост по имени
        return postRepository.existsByName(name);
    }

    public List<Post> getPosts(){
        // Функция, которая возвращает все посты из БД
        return postRepository.findAll();
    }

    public  Post getPost(String name){
        // Функция, которая возвращает пост по имени
        return postRepository.findPostByName(name);
    }
    public void delPost(String name){
        // Функция, которая удаляет пост по имени
        postRepository.deleteByName(name);
    }
    public Long updatePost(Long id, String name, String about, List<Category> categoryList, Date createTime, Date updateTime){
        // Функция, которая обновляет информацию о посте
        Post post = postRepository.findPostByName(name);
        post.setId(id);
        post.setName(name);
        post.setAbout(about);
        post.setCategoryList(categoryList);
        post.setCreateTime(createTime);
        post.setUpdateTime(updateTime);
        Post updated_post = postRepository.save(post);
        return updated_post.getId();
    }
    public Post findPostByID(Long id){
        // Функция, которая возвращает пост по id
        return postRepository.findById(id).get();
}
}
