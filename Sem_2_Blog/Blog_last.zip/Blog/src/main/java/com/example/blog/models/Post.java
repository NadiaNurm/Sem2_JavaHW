package com.example.blog.models;


import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

import java.util.Date;
import java.util.List;
import java.util.Set;

@Entity
public class Post {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String name;
    private String about;
    private Date createTime;
    private Date updateTime;

   /*
     ManyToMany – многие-ко-многим
     Если параметр fetch принимает значение LAZY, то при загрузке родительской сущности, дочерняя сущность загружена не будет. Вместо нее будет создан proxy-объект.
     С помощью этого proxy-объекта Hibernate будет отслеживать обращение к этой дочерней сущности и при первом обращении загрузит ее в память.
     @JoinTable определяет таблицу и поля для связи.
     Параметр name указывает название таблицы (posts_categories).
     Параметр joinColumns указывает на поле, которое используется для прямой связи (идентификатор post_id).
     Параметр inverseJoinColumns указывает на поле, которое используется для обратной связи (идентификатор category_id).
     Для указания столбцов связи из таблицы используется аннотация @JoinColumn.
    */
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "posts_categories",
            joinColumns = @JoinColumn(name = "post_id"),
            inverseJoinColumns = @JoinColumn(name="category_id")
            )
    private List<Category> categoryList;

    public Post(Long id, String name, String about, List<Category> categoryList,Date createTime,Date updateTime) {
        this.id = id;
        this.name = name;
        this.about = about;
        this.categoryList = categoryList;
        this.createTime = createTime;
        this.updateTime = updateTime;
    }
    public Post( String name, String about, List<Category> categoryList,Date createTime,Date updateTime) {
        this.name = name;
        this.about = about;
        this.categoryList = categoryList;
        this.createTime = createTime;
        this.updateTime = updateTime;
    }
    public Post( String name, String about, List<Category> categoryList,Date createTime) {
        this.name = name;
        this.about = about;
        this.categoryList = categoryList;
        this.createTime = createTime;
    }
    public Post(){}

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getAbout() {
        return about;
    }

    public void setAbout(String about) {
        this.about = about;
    }

    public List<Category> getCategoryList() {
        return categoryList;
    }

    public void setCategoryList(List<Category> categoryList) {
        this.categoryList = categoryList;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        return "Post{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", about='" + about + '\'' +
                ", createTime=" + createTime +
                ", updateTime=" + updateTime +
                ", categoryList=" + categoryList +
                '}';
    }
}
