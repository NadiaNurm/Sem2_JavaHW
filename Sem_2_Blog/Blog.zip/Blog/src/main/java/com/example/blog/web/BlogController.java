package com.example.blog.web;

import com.example.blog.models.User;
import com.example.blog.repositories.UserRepository;
import com.example.blog.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.Date;

@Controller
public class BlogController {
    @Autowired
    UserService userService;
    @GetMapping("/main")
    public String hello(Model model){
        return "main";
    }

    @PostMapping("/main")
    public String formTest(@RequestParam(name="firstName") String firstName,
                           @RequestParam(name="lastName") String lastName,
                           @RequestParam(name="middleName") String middleName,
                           @RequestParam (name="data",required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date birthday, Model model){

        userService.addUser(firstName,lastName,middleName,birthday);
        return "main";
    }


}
