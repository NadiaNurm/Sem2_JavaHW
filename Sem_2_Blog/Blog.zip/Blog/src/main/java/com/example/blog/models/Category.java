package com.example.blog.models;

import jakarta.persistence.*;


import java.util.Date;
import java.util.List;

@Entity
public class Category {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String name;
    private Type type;
    @ManyToMany(mappedBy = "categoryList")
    List<Post> postList;


    public Category(String name, Type type) {
        this.name = name;
        this.type = type;
    }

    public Category() {

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public List<Post> getPostList() {
        return postList;
    }

    public void setPostList(List<Post> postList) {
        this.postList = postList;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public enum Type {
        Lifestyle,
        Decor,
        Health,
        Parent,
        Religious
    }

}
