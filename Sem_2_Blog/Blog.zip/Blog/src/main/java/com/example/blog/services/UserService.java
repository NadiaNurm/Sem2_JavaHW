package com.example.blog.services;

import com.example.blog.models.User;
import com.example.blog.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class UserService {
   @Autowired
   UserRepository userRepository;
   public void addUser(String firstName, String lastName, String middleName, Date birthday){
       User user = new User(firstName,lastName,middleName,birthday);
       userRepository.save(user);
   }
}
