package com.example.kinoprokatrest.models;

public enum Genres {
    adventure, animation, action,
    biography,
    comedy,crime,
    drama, documentary,
    fiction, film_noir, fantasy,family,
    history, horror,
    musical,music,mystery,
    romcom, romance,
    science, sci_fi,sport,
    thriller,
    western,war
    ;






}
