package com.example.kinoprokatrest.models;

public enum SubType {
    week,month,year;
}
