package com.example.kinoprokatrest;

public class Main {
    public static void main(String[] args) {
        //Sat Jan 01 00:00:00 MSK 1994
    }
}
