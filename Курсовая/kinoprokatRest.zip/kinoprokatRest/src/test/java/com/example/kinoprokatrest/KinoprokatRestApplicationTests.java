package com.example.kinoprokatrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KinoprokatRestApplicationTests {

    @Test
    void contextLoads() {
    }

}
