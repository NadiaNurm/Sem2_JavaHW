package org.example;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException, ParseException {
        String dateStr = "Sat Jan 01 00:00:00 MSK 1994";
        DateFormat formatter = new SimpleDateFormat("EEE MMM dd HH:mm:ss Z yyyy", Locale.US);
        Date date = (Date)formatter.parse(dateStr);
        System.out.println(date);

        //   parseFilms();
    }

    public static void parseFilms() throws IOException {
        ArrayList<String> linksList = new ArrayList<>();
        ArrayList<Film> filmsList = new ArrayList<>();
        Document doc  = Jsoup.connect("https://www.imdb.com/chart/top/?ref_=nv_mv_250").get();

        // Get links from document object.
        Elements links = doc.select(".posterColumn> a[href]");
        int counter = 0;
        for (Element link : links) {
           //counter += 1;
           //if(counter >5){
           //    break;
           //}
            Film film = new Film();
            Document doc1  = Jsoup.connect("https://www.imdb.com/" + link.attr("href")).get();

            Elements name = doc1.select("span.sc-afe43def-1.fDTGTb");
            film.setName(name.text());

            Elements images =  doc1.select("img[src~=(?i)\\.(png|jpe?g|gif)]");
            film.setImage(images.attr("src"));

            Elements director = doc1.select( "ul.ipc-inline-list.ipc-inline-list--show-dividers.ipc-inline-list--inline.ipc-metadata-list-item__list-content.baseAlt");
            film.setDirector(director.get(0).text());

            Elements genres = doc1.select( "span.ipc-chip__text");
            List<String> genresList = new ArrayList<>();
            for (Element g : genres) {
                if(!g.text().equals("Back to top")){
                    genresList.add(g.text());
                }
            }
            film.setGenres(genresList);

            Elements about = doc1.select( "span.sc-5f699a2-2.cxqNYC");
            film.setAbout(about .text());


            String[] elements = doc1.select( "ul.ipc-inline-list.ipc-inline-list--show-dividers.sc-afe43def-4.kdXikI.baseAlt").text().split(" ",3);

            int year = Integer.parseInt(elements[0]);
            Calendar calendar = new GregorianCalendar(year, 0 , 1);
            Date date = calendar.getTime();
            film.setDate(date);

            film.setAgeRestriction(elements[1]);
       // System.out.println(elements[2]);
            String [] len = elements[2].split(" ");
            if(len.length ==2) {
                int hours = 60 * Integer.parseInt(len[0].replace("h", ""));
                int minutes = Integer.parseInt(len[1].replace("m", ""));
                film.setLenght("" + (hours + minutes));
            }
            else {
                film.setLenght(len[0].replace("m", ""));
            }
            filmsList.add(film);


            //  Elements images =  doc.select("img[src~=(?i)\\.(png|jpe?g|gif)]");
            //  for (Element image : images) {
            //      Film film = new Film();
            //      film.setName(image.attr("alt"));
            //      film.setImage(image.attr("src"));
            //      filmsList.add(film);
            //      // System.out.println("Image Source: " + image.attr("src"));
            //      // System.out.println("Image Alt Text: " + image.attr("alt"));
            //  }

    }
        try {
        BufferedWriter writer = new BufferedWriter(new FileWriter(new File("films.txt")));
            for (Film film : filmsList) {
                String text = film.getName() + ";" + film.getDirector() + ";" + film.getLenght() + ";" + film.getAbout() +  ";" + film.getAgeRestriction() + ";" + film.getDate() + ";" + film.getGenres() + ";" + film.getImage() ;
                writer.write(text);
                writer.flush();
                writer.newLine();
            }
        }
        catch(IOException ex){

            System.out.println(ex.getMessage());
        }
    }
}

