package org.example;

import java.util.Date;
import java.util.List;

public class Film {
    String name;
    String ageRestriction;
    String director;
    String lenght;
    String about;
    String image;
    List<String> genres;
    Date date;

    public Film(String name, String ageRestriction, String director, String lenght, String about, String image, List<String> genres, Date date) {
        this.name = name;
        this.ageRestriction = ageRestriction;
        this.director = director;
        this.lenght = lenght;
        this.about = about;
        this.image = image;
        this.genres = genres;
        this.date = date;
    }

    public Film() {

    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAgeRestriction() {
        return ageRestriction;
    }

    public void setAgeRestriction(String ageRestriction) {
        this.ageRestriction = ageRestriction;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getLenght() {
        return lenght;
    }

    public void setLenght(String lenght) {
        this.lenght = lenght;
    }

    public String getAbout() {
        return about;
    }

    public void setAbout(String about) {
        this.about = about;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public List<String> getGenres() {
        return genres;
    }

    public void setGenres(List<String> genres) {
        this.genres = genres;
    }

    @Override
    public String toString() {
        return "Film{" +
                "name='" + name + '\'' +
                ", ageRestriction='" + ageRestriction + '\'' +
                ", director='" + director + '\'' +
                ", lenght=" + lenght +
                ", about='" + about + '\'' +
                ", image='" + image + '\'' +
                ", genres=" + genres +
                ", date=" + date +
                '}';
    }
}
