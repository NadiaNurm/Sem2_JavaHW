package com.example.trainfront;

import lombok.Data;

import java.util.List;
/**
 * Класс поезда со свойствами <b>id</b>, <b>name</b>, <b>trainType</b> и <b>carriages</b>.
 * @author Нурминская Надежда
 * @version 1
 */
@Data
public class Train {
    /** Поле id */
    private Long id;
    /** Поле name */
    private String name;
    /** Поле trainType */
    private TrainType trainType;

    //private int seats;
    /** Поле carriages */
    private List<Carriage> carriages;

    /**
     * Конструктор - создание нового объекта поезда
     * @param id - уникальный идентификатор поезда
     * @param name - имя поезда
     * @param trainType - тип поезда
     * @param carriages - список вагонов поезда
     * @see Train#Train()
     */
    public Train(Long id, String name, TrainType trainType, List<Carriage> carriages) {
        this.id = id;
        this.name = name;
        this.trainType = trainType;
        this.carriages = carriages;
    }

    /**
     * Конструктор - создание нового объекта поезда
     * @see Train#Train(Long, String, TrainType, List<Carriage>)
     */
    public Train() {

    }
}
