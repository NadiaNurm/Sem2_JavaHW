package com.example.trainfront;

import lombok.Data;

import java.util.Objects;
/**
 * Класс рейса со свойствами <b>id</b>, <b>cityFrom</b>, <b>cityWhere</b>,
 * <b>departureDate</b>, <b>departureTime</b>, <b>arrivalDate</b>, <b>arrivalTime</b>,
 * <b>basePrice</b> и <b>train</b>.
 * @author Нурминская Надежда
 * @version 1
 */
@Data
public class Flight {
    /** Поле id
     * Идентификатор рейса
     */
    private Long id;
    /** Поле cityFrom
     * Город отправления
     */
    private String cityFrom;
    /** Поле cityWhere
     * Город прибытия
     */
    private String cityWhere;
    /** Поле departureDate
     * Дата отправления
     */
    private String  departureDate;
    /** Поле departureTime
     * Время отправления
     */
    private String departureTime;
    /** Поле arrivalDate
     * Дата прибытия
     */
    private String  arrivalDate;
    /** Поле arrivalTime
     * Время прибытия
     */
    private String arrivalTime;
    /** Поле basePrice
     * Базовая цена
     */
    private int basePrice;
    /** Поле train
     * Поезд, который привязан к этому рейсу
     */
    private Train train;
    /**
     * Конструктор - создание нового объекта рейса
     * @param id - уникальный идентификатор рейса
     * @param cityFrom - город отправления
     * @param cityWhere - город прибытия
     * @param departureDate - дата отправления
     * @param departureTime - время отправления
     * @param arrivalDate - дата прибытия
     * @param arrivalTime - время прибытия
     * @param basePrice - базовая цена
     * @param train - поезд на рейс
     * @see Flight#Flight()
     */
    public Flight(Long id, String cityFrom, String cityWhere, String departureDate, String departureTime, String arrivalDate, String arrivalTime, int basePrice, Train train) {
        this.id = id;
        this.cityFrom = cityFrom;
        this.cityWhere = cityWhere;
        this.departureDate = departureDate;
        this.departureTime = departureTime;
        this.arrivalDate = arrivalDate;
        this.arrivalTime = arrivalTime;
        this.basePrice = basePrice;
        this.train = train;
    }
    /**
     * Конструктор - создание нового объекта рейса
     * @see Flight#Flight(Long, String, String, String, String, String, String,int,Train)
     */
    public Flight() {

    }


}
