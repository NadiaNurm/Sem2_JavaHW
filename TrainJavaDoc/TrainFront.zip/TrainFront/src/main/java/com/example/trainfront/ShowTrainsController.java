package com.example.trainfront;

import java.io.IOException;
import java.net.URL;
import java.util.*;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.Button;
/**
 * Контроллер для отображения списка поездов
 */
public class ShowTrainsController {

    @FXML
    private ResourceBundle resources;
    @FXML
    private URL location;
    @FXML
    private Button trainsAddFlight;
    @FXML
    private Button trainsAddTrain;
    @FXML
    private Button trainsFlights;
    @FXML
    private TableView<TrainDTO> trainsTable;
    @FXML
    private TableColumn<TrainDTO, Integer> trainsCarriageColumn;

    @FXML
    private TableColumn<TrainDTO, String> trainsNameColumn;

    @FXML
    private TableColumn<TrainDTO, Integer> trainsSeatsColumn;

    @FXML
    private TableColumn<TrainDTO, TrainType> trainsTypeColumn;
    /**
     * Отображает все поезда в таблице
     * @throws Exception
     */
    @FXML
    void initialize() throws Exception {
         String jsonTrainArray = Util.sendGet("http://localhost:8080/allTrains");
         ObjectMapper objectMapper = new ObjectMapper();
         List<Train> listTrain = objectMapper.readValue(jsonTrainArray, new TypeReference<List<Train>>(){});
         List<TrainDTO> trainDTOList = Util.createTrainDAO(listTrain);

        // List<TrainType> types = new ArrayList<TrainType>(Arrays.asList(TrainType.values()));
         ObservableList<TrainDTO> trains = FXCollections.observableArrayList(trainDTOList);
         trainsNameColumn.setCellValueFactory(new PropertyValueFactory<TrainDTO, String>("name"));
         trainsTypeColumn.setCellValueFactory(new PropertyValueFactory<TrainDTO, TrainType>("trainType"));
         trainsSeatsColumn.setCellValueFactory(new PropertyValueFactory<TrainDTO, Integer>("seats"));
         trainsCarriageColumn.setCellValueFactory(new PropertyValueFactory<TrainDTO, Integer>("carriages"));
         trainsTable.setItems(trains);

        trainsFlights.setOnAction(x ->{
            try {
                Util.openPage("hello-view.fxml", trainsFlights);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });

        trainsAddTrain.setOnAction(x ->{
            try {
                Util.openPage("addTrain.fxml",trainsAddTrain);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });

        trainsAddFlight.setOnAction(x ->{
            try {
                Util.openPage("addFlight.fxml", trainsAddFlight);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });



    }

}



