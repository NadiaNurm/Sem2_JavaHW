package com.example.trainfront;
/**
 * Словарь для типов поезда
 */
public enum TrainType {
    lastochka,sapsan,strizh,nevsky;
}
