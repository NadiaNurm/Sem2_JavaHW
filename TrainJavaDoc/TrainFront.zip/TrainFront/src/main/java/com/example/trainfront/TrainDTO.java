package com.example.trainfront;

import lombok.Data;

import java.util.List;

/**
 * Класс представления поезда со свойствами  <b>name</b>, <b>trainType</b>,<b>seats</b> и <b>carriages</b>.
 * @author Нурминская Надежда
 * @version 1
 */
@Data
public class TrainDTO {
    /** Поле name */
    private String name;
    /** Поле trainType */
    private TrainType trainType;
    /** Поле seats */
    private int seats;
    /** Поле carriages */
    private int carriages;


    /**
     * Конструктор - создание нового объекта поезда
     * @param name - имя поезда
     * @param trainType - тип поезда
     * @param seats - количество мест
     * @param carriages - список вагонов поезда
     * @see TrainDTO#TrainDTO()
     */
    public TrainDTO(String name, TrainType trainType, int seats, int carriages) {
        this.name = name;
        this.trainType = trainType;
        this.seats = seats;
        this.carriages = carriages;
    }

    /**
     * Конструктор - создание нового объекта поезда
     * @see TrainDTO#TrainDTO(String, TrainType, int, int)
     */
    public TrainDTO() {
    }

}
