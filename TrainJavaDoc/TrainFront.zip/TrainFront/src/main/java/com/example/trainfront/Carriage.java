package com.example.trainfront;

import lombok.Data;

import java.util.List;
/**
 * Класс вагона со свойствами <b>id</b>, <b>freeSeats</b>
 * @author Нурминская Надежда
 * @version 1
 */
@Data
public class Carriage {
    /** Поле id
     * Идентификатор вагона
     */
    private Long id;
    /** Поле freeSeats
     * Список свободных мест в вагоне
     */
    List<Boolean> freeSeats;

    public Carriage(Long id, List<Boolean> freeSeats) {
        this.id = id;
        this.freeSeats = freeSeats;
    }
    /**
     * Конструктор - создание нового объекта вагона
     */
    public Carriage() {
    }


}
