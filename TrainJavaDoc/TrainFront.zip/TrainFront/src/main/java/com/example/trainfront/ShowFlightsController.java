package com.example.trainfront;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
/**
 * Контроллер для отображения списка рейсов
 */
public class ShowFlightsController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button mainAddFlight;

    @FXML
    private Button mainAddTrain;

    @FXML
    private TextField mainCityFrom;

    @FXML
    private TextField mainCityWhere;
    @FXML
    private TableView<FlightDTO> mainTable;
    @FXML
    private TableColumn<FlightDTO, String> mainTableArrDate;
    @FXML
    private TableColumn<FlightDTO, String> mainTableArrTime;
    @FXML
    private TableColumn<FlightDTO, Integer> mainTableAvailable;
    @FXML
    private TableColumn<FlightDTO, String> mainTableDepTime;
    @FXML
    private TableColumn<FlightDTO, String> mainTableDeparture;
    @FXML
    private TableColumn<FlightDTO, String> mainTableFrom;
    @FXML
    private TableColumn<FlightDTO, Integer> mainTableSeats;
    @FXML
    private TableColumn<FlightDTO, String> mainTableWhere;
    @FXML
    private TableColumn<FlightDTO, String> mainTableTrainName;
    @FXML
    private Button mainTrains;
    @FXML
    private ComboBox<?> todoCategory;
    private ObservableList<FlightDTO> flights = FXCollections.observableArrayList();;
    @FXML
    void initialize() throws Exception {
        addButtonToTable();
        printTable();

        mainTrains.setOnAction(x ->{
            try {
                Util.openPage("trains.fxml",mainTrains);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });

        mainAddTrain.setOnAction(x ->{
            try {
                Util.openPage("addTrain.fxml",mainAddTrain);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });

        mainAddFlight.setOnAction(x ->{
            try {
                Util.openPage("addFlight.fxml", mainAddFlight);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
    }
    /**
     * Добавляет кнопку покупки билета для всех рейсов в таблице.
     * При ее нажатии отправляет информацию на сервер, что билет на указанный рейс куплен.
     * После этого информация в таблице отправляется.
     */
    private void addButtonToTable() {
        TableColumn<FlightDTO, Void> colBtn = new TableColumn("Buy ticket");
        Callback<TableColumn<FlightDTO, Void>, TableCell<FlightDTO, Void>> cellFactory = new Callback<TableColumn<FlightDTO, Void>, TableCell<FlightDTO, Void>>() {
            @Override
            public TableCell<FlightDTO, Void> call(final TableColumn<FlightDTO, Void> param) {
                final TableCell<FlightDTO, Void> cell = new TableCell<FlightDTO, Void>() {
                    private final Button btn = new Button("Buy");

                    {
                        btn.setOnAction((ActionEvent event) -> {
                            FlightDTO flightDTO = getTableView().getItems().get(getIndex());
                            String trainName = flightDTO.getTrainName();
                            try {
                                sendBuyTicket(trainName);
                                printTable();
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }
                        });
                    }
                    @Override
                    public void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            setGraphic(btn);
                        }
                    }
                };
                return cell;
            }
        };
        colBtn.setCellFactory(cellFactory);
        mainTable.getColumns().add(colBtn);
    }

    /**
     * Формирует запрос на покупку билета, то есть занимает свободное место в вагоне
     * @param trainName String
     * @throws Exception
     */
    private void sendBuyTicket(String trainName) throws Exception {

        HttpPost post = new HttpPost("http://localhost:8080/buyTicket");

        // add request parameter, form parameters
        List<NameValuePair> urlParameters = new ArrayList<>();
        urlParameters.add(new BasicNameValuePair("train", trainName));

        post.setEntity(new UrlEncodedFormEntity(urlParameters));

        try (CloseableHttpClient httpClient = HttpClients.createDefault();
             CloseableHttpResponse response = httpClient.execute(post)) {
            System.out.println(EntityUtils.toString(response.getEntity()));
        }

    }
    /**
     * Отображает все рейсы в таблице
     * @throws Exception
     */
    public void printTable() throws Exception {
        flights.clear();
        upload();
        mainTableArrDate.setCellValueFactory(new PropertyValueFactory<FlightDTO, String>("arrivalDate"));
        mainTableArrTime.setCellValueFactory(new PropertyValueFactory<FlightDTO, String>("arrivalTime"));
        mainTableAvailable.setCellValueFactory(new PropertyValueFactory<FlightDTO, Integer>("availableSeats"));
        mainTableDepTime.setCellValueFactory(new PropertyValueFactory<FlightDTO, String>("departureTime"));
        mainTableDeparture.setCellValueFactory(new PropertyValueFactory<FlightDTO, String>("departureDate"));
        mainTableFrom.setCellValueFactory(new PropertyValueFactory<FlightDTO, String>("cityFrom"));
        mainTableSeats.setCellValueFactory(new PropertyValueFactory<FlightDTO, Integer>("seats"));
        mainTableWhere.setCellValueFactory(new PropertyValueFactory<FlightDTO, String>("cityWhere"));
        mainTableTrainName.setCellValueFactory(new PropertyValueFactory<FlightDTO, String>("trainName"));
        mainTable.setItems(flights);
    }
    /**
     * Обновляет информацию после покупки билета
     * @throws Exception
     */
    public void upload() throws Exception {
        String jsonTrainArray = Util.sendGet("http://localhost:8080/allFlights");
        ObjectMapper objectMapper = new ObjectMapper();
        List<Flight> listFlight = objectMapper.readValue(jsonTrainArray, new TypeReference<List<Flight>>(){});
        List<FlightDTO> flightDTOList = Util.createFlightDAO(listFlight);
        flights.addAll(flightDTOList);
    }

}
