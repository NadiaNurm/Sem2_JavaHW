package com.example.trainfront;

import lombok.Data;

import java.util.Objects;
/**
 * Класс представления рейса со свойствами <b>cityFrom</b>, <b>cityWhere</b>,
 * <b>departureDate</b>, <b>departureTime</b>, <b>arrivalDate</b>, <b>arrivalTime</b>,
 * <b>basePrice</b> , <b>availableSeats</b> и <b>trainName</b>.
 * @author Нурминская Надежда
 * @version 1
 */
@Data
public class FlightDTO {
    /** Поле cityFrom
     * Город отправления
     */
    private String cityFrom;
    /** Поле cityWhere
     * Город прибытия
     */
    private String cityWhere;
    /** Поле departureDate
     * Дата отправления
     */
    private String  departureDate;
    /** Поле departureTime
     * Время отправления
     */
    private String departureTime;
    /** Поле arrivalDate
     * Дата прибытия
     */
    private String  arrivalDate;
    /** Поле arrivalTime
     * Время прибытия
     */
    private String arrivalTime;
    /** Поле basePrice
     * Базовая цена
     */
    private int basePrice;
    /** Поле seats
     * Количество мест в поезде
     */
    private int seats;
    /** Поле availableSeats
     * Количество свободных мест в поезде
     */
    private int availableSeats;
    /** Поле trainName
     * Название поезда, который привязан к этому рейсу
     */
    private String trainName;

    /**
     * Конструктор - создание нового объекта рейса
     * @param cityFrom - город отправления
     * @param cityWhere - город прибытия
     * @param departureDate - дата отправления
     * @param departureTime - время отправления
     * @param arrivalDate - дата прибытия
     * @param arrivalTime - время прибытия
     * @param basePrice - базовая цена
     * @param seats - количество мест в поезде
     * @param availableSeats - количество свободных мест в поезде
     * @param trainName - название поезда на рейс
     * @see FlightDTO#FlightDTO()
     */
    public FlightDTO(String cityFrom, String cityWhere, String departureDate, String departureTime, String arrivalDate, String arrivalTime, int basePrice, int seats, int availableSeats, String trainName) {
        this.cityFrom = cityFrom;
        this.cityWhere = cityWhere;
        this.departureDate = departureDate;
        this.departureTime = departureTime;
        this.arrivalDate = arrivalDate;
        this.arrivalTime = arrivalTime;
        this.basePrice = basePrice;
        this.seats = seats;
        this.availableSeats = availableSeats;
        this.trainName = trainName;
    }
    /**
     * Конструктор - создание нового объекта рейса
     * @see FlightDTO#FlightDTO(String, String, String , String , String , String, int, int, int, String)
     */
    public FlightDTO() {
    }
}
