package com.example.trainrest.models;
/**
 * Словарь для типов поезда
 */
public enum TrainType {
    lastochka,sapsan,strizh,nevsky;

}
