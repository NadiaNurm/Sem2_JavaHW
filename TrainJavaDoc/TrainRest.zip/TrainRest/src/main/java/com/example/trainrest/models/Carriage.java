package com.example.trainrest.models;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;
/**
 * Класс вагона со свойствами <b>id</b>, <b>freeSeats</b>
 * @author Нурминская Надежда
 * @version 1
 */
@Entity
@Data
public class Carriage {
    /** Поле id
     * Идентификатор вагона
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    /** Поле freeSeats
     * Список свободных мест в вагоне
     */
    @ElementCollection
    List<Boolean> freeSeats;
    /**
     * Конструктор - создание нового объекта вагона
     * @param freeSeats - список свободных мест в вагоне
     * @see Carriage#Carriage()
     */
    public Carriage(List<Boolean> freeSeats) {
        this.freeSeats = freeSeats;
    }
    /**
     * Конструктор - создание нового объекта вагона
     * @see Carriage#Carriage(List<Boolean>)
     */
    public Carriage() {

    }
}
