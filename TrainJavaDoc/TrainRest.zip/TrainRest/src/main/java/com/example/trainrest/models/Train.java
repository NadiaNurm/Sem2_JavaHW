package com.example.trainrest.models;

import jakarta.persistence.*;

import java.util.HashMap;
import java.util.List;
import java.util.Objects;
/**
 * Класс поезда со свойствами <b>id</b>, <b>name</b>, <b>trainType</b> и <b>carriages</b>.
 * @author Нурминская Надежда
 * @version 1
 */
@Entity
public class Train {
    /** Поле id */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    /** Поле name */
    private String name;
    /** Поле trainType */
    @Enumerated(EnumType.STRING)
    private TrainType trainType;
    /** Поле carriages */
    @OneToMany()
    private List<Carriage> carriages;

    /**
     * Конструктор - создание нового объекта поезда
     * @param id - уникальный идентификатор поезда
     * @param name - имя поезда
     * @param trainType - тип поезда
     * @param carriages - список вагонов поезда
     * @see Train#Train()
     */
    public Train(Long id, String name, TrainType trainType, List<Carriage> carriages) {
        this.id = id;
        this.name = name;
        this.trainType = trainType;
        this.carriages = carriages;
    }

    /**
     * Конструктор - создание нового объекта поезда
     * @see Train#Train(Long, String, TrainType, List<Carriage>)
     */
    public Train() {

    }
    /**
     * Функция получения значения поля {@link Train#id}
     * @return возвращает id поезда
     */
    public Long getId() {
        return id;
    }
    /**
     * Процедура определения значения поля {@link Train#id}
     * @param id - список id поезда
     */
    public void setId(Long id) {
        this.id = id;
    }
    /**
     * Функция получения значения поля {@link Train#name}
     * @return возвращает имя поезда
     */
    public String getName() {
        return name;
    }
    /**
     * Процедура определения значения поля {@link Train#name}
     * @param name - список имя поезда
     */
    public void setName(String name) {
        this.name = name;
    }
    /**
     * Функция получения значения поля {@link Train#trainType}
     * @return возвращает тип поезда
     */
    public TrainType getTrainType() {
        return trainType;
    }
    /**
     * Процедура определения значения поля {@link Train#trainType}
     * @param trainType - список тип поезда
     */
    public void setTrainType(TrainType trainType) {
        this.trainType = trainType;
    }


    /**
     * Функция получения значения поля {@link Train#carriages}
     * @return возвращает список вагонов поезда
     */
    public List<Carriage> getCarriages() {
        return carriages;
    }
    /**
     * Процедура определения значения поля {@link Train#carriages}
     * @param carriages - список вагонов поезда
     */
    public void setCarriages(List<Carriage> carriages) {
        this.carriages = carriages;
    }
    /**
     * Метод toString() преобразует объект в строковое представление.
     * @return строковое представление объекта со всеми полями.
     */
    @Override
    public String toString() {
        return "Train{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", trainType=" + trainType +


                '}';
    }


}
