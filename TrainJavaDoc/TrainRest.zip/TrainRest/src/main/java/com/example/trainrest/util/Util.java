package com.example.trainrest.util;

import com.example.trainrest.models.Carriage;
import com.example.trainrest.models.Train;
import com.example.trainrest.services.CarriageService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;
/**
 * Класс-утилита для создания вагонов поезда
 */
public class Util {
    /**
     * Создает вагоны и добавляет их в поезд.
     * В каждом поезде по amountCarr вагонов
     * @param train Train
     * @param amountCarr int
     * @param seats int
     * @return carriages
     */
    public static List<Carriage> addCarriages(Train train, int amountCarr, int seats) {

        List<Carriage> carriages = new ArrayList<>();
        for (int i = 0; i < amountCarr; i++) {
            List<Boolean> b = new ArrayList<>();
            for (int j = 0; j < seats; j++) {
                b.add(true);
            }
            Carriage carriage = new Carriage(b);
            carriages.add(carriage);
        }
        return carriages;


    }


}
