package com.example.kinoprokat.model;

import javax.persistence.*;

import java.util.Date;

@Entity
@Data
public class Purchase {
    /*
       Модель покупки товара.
   */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @OneToOne
    private Item item;

    private LocalDate date;

    public Purchase() {

    }


}
