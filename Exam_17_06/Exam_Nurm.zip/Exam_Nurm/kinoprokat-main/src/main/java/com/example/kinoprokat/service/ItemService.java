package com.example.kinoprokat.service;
@Service
public class ItemService {
    @Autowired
    ItemRepository itemRepository;
    public List<Item> getAllItems() {
        return itemRepository.findAll();
    }

    public Long saveItem(Item item) {
        return itemRepository.save(purchase).getId();
    }
}
