package com.example.kinoprokat.repository;

import org.hibernate.cache.spi.support.AbstractReadWriteAccess;

public interface ItemRepository extends JpaRepository<Item, Long> {

    public boolean existsByName(String name);

    public Item getItemByName(String name);
    public void deleteById(Long id);
}
