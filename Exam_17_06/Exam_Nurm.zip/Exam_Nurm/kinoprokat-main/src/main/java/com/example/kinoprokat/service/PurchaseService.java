package com.example.kinoprokat.service;

import com.example.kinoprokat.dto.FilmDTO;
import com.example.kinoprokat.model.Film;
import com.example.kinoprokat.model.Purchase;
import com.example.kinoprokat.repository.PurchaseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class PurchaseService {
    @Autowired
    PurchaseRepository purchaseRepository;

    public List<Purchase> getAllPurchase() {
        return purchaseRepository.findAll();
    }

    public Long savePurchase(Purchase purchase) {
        return purchaseRepository.save(purchase).getId();

    }

}
