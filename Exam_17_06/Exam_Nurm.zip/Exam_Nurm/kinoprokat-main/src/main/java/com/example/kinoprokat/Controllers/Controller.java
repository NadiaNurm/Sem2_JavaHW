package com.example.kinoprokat.Controllers;
@RestController
public class Controller {
    @Autowired
    ItemService itemservice;
    @Autowired
    PurchaseService purchaseService;

    @GetMapping("/allItems")
    public ResponseEntity<?> printItems() {
        List<Item> ItemList = itemservice.getAllItems();
        return new ResponseEntity<>(ItemList, HttpStatus.OK);
    }

    @PostMapping("/addItem")
    public ResponseEntity<?> addItem(@Validated @RequestBody Item item) {
        // Добавляет товар в базу
        Long id = itemservice.saveItem(item);
        return new ResponseEntity<>("User created, id: " + id, HttpStatus.OK);
    }

    @PutMapping("/buyItem")
    public ResponseEntity<?> buyItem(@RequestBody Item item) {
        // Покупаем товар
        Purchase purchase = new Purchaise();
        LocalDate date = LocalDate.now();
        purchase.setDate(date);
        purchase.setItem(item);
        purchaseService.savePurchase(purchase);
        return new ResponseEntity<>("Item bought", HttpStatus.OK);
    }


}
