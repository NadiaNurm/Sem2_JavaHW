package com.example.todolist.services;

import com.example.todolist.models.Task;
import com.example.todolist.models.User;
import com.example.todolist.repositories.TaskRepository;
import com.example.todolist.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Date;
import java.util.List;

@Service
public class TaskService {
    @Autowired
    private TaskRepository taskRepository;
    public List<Task> getTasks(){
        // Функция, которая возвращает все задания из БД
        return taskRepository.findAll();
    }
    public  Task getTask(String name){
        // Функция, которая возвращает задание по имени
        return taskRepository.findTaskByName(name);
    }
    public void delTask(String name){
        // Функция, которая удаляет задание по имени
        taskRepository.deleteByName(name);
    }
    public Long addTask(Task task){
        // Функция, которая добавляет задание в базу данных и возвращает Id созданного задания
        task.setCreateTime(new Date());
        return taskRepository.save(task).getId();
    }

    public boolean existsByName(String name){
        // Функция, которая проверяет, существует ли задание по имени
        return taskRepository.existsByName(name);
    }
    public Task findTaskByID(Long id){
        // Функция, которая возвращает задание по id
        return taskRepository.findById(id).get();
    }

    public Long updateTask(Task task){
        // Функция, которая id задания и обновляет его
        task.setUpdateTime(new Date());
        return taskRepository.save(task).getId();
    }

    public void makeTask(String name){
        // Функция, которая отмечает задание, как выполненное
        Task task = getTask(name);
        task.makeTask();
        task.setDoneDate(new Date());
        taskRepository.save(task);
    }


}
