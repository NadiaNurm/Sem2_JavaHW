package com.example.todolist.services;

import com.example.todolist.models.User;
import com.example.todolist.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;
    public Long addUser(User user){
        user.setCreateTime(new Date());
        return userRepository.save(user).getId();
    }
    public List<User> getUsers(){
        return userRepository.findAll();
    }

    public void delUser(String login){
        userRepository.deleteByLogin(login);
    }
    public User getUser(String login){
        return userRepository.findByLogin(login);
    }
    public User findByID(Long id){
        return userRepository.findById(id).get();
    }

    public Long updateUser(User user){
        user.setUpdateTime(new Date());
        return userRepository.save(user).getId();
    }

    public boolean existsByLogin(String login){
        return userRepository.existsByLogin(login);
    }
}
