package com.example.todolist.controllers;

import com.example.todolist.models.Category;
import com.example.todolist.models.Task;
import com.example.todolist.models.User;
import com.example.todolist.services.CategoryService;
import com.example.todolist.services.TaskService;
import com.example.todolist.services.UserService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/*
{
        "name":"4",
        "about": "test5"

        }
*/
@RestController
public class TaskController {
    @Autowired
    private TaskService taskService;
    @Autowired
    CategoryService categoryService;
    @Autowired
    private UserService userService;
    @GetMapping("/getTasks")
    public ResponseEntity<?> getTasks(){
        // возвращаем все задание из БД
        List<Task> tasks = taskService.getTasks();

        if(tasks.isEmpty()){
            return new ResponseEntity<>("No tasks yet", HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(tasks,HttpStatus.OK);
    }

    @PutMapping("/makeTask")
    public ResponseEntity<?> makeTask(@RequestParam (name="name") String name){
        if(taskService.existsByName(name)){
            taskService.makeTask(name);
            return new ResponseEntity<>("Mission accomplished!", HttpStatus.OK);
        }
        return new ResponseEntity<Task>(HttpStatus.NOT_FOUND);
    }
    @PostMapping("/addTask")
    public ResponseEntity<?> addTask(@RequestBody Task task, @RequestParam (name="id_user") Long id_user, @RequestParam (name="category_id_list",required = false) Long[] category_id_list) {
        // ппередаем задание, которое хотим добавить; id_user для юзера, которому принадлежит задание; список из id категорий;

        if(id_user == null){
            // задание должно принадлежать какому-то конкретному юзеру, поэтому при создании задания мы должны передать параметр для идентификации (id_user)
            return new ResponseEntity<>("No id_user",HttpStatus.NOT_FOUND);
        }
        if(taskService.existsByName(task.getName())){
            // проверяем, нет ли такого задания с таким именем
            return new ResponseEntity<>("Task already exist",HttpStatus.INTERNAL_SERVER_ERROR);
        }

        // получаем Id созданного задания
        Long  id_task = taskService.addTask(task);
        // получаем юзера, которому должно принадлежать задание
        User user = userService.findByID(id_user);
        // получаем наше задание по Id, который мы получили при создании
        Task task1 = taskService.findTaskByID(id_task);
        // получаем список заданий нужного юзера и добавляем задание
        user.getTasks().add(task1);
        userService.addUser(user);

        // получаем список категорий по id из списка,который мы передали в параметрах
        List<Category> categories = new ArrayList<>();
        for (Long id_cat : category_id_list) {
            Category cat = categoryService.findCatById(id_cat);
            categories.add(cat);
        }
        // добавляем список категорий и добавляем задание
        task1.setCategoryList(categories);
        taskService.addTask(task1);

        // получаем список заданий для каждой категории и добавляем в него наше задание
        for (Category cat : categories) {
            cat.getTaskList().add(task1);
            categoryService.addCategory(cat);
        }
        // возвращаем id созданного задания
        return new ResponseEntity<>("Task created, id: " + id_task,HttpStatus.OK);
    }

    @PutMapping("/updateTask")
    public ResponseEntity<?> updateTask(@RequestBody Task task){
        // обновляет информацию о задании, если оно существует
        if(taskService.existsByName(task.getName())){
            Long id = taskService.updateTask(task);
            return new ResponseEntity<>("Task " + id + "updated",HttpStatus.OK);
        }
        return new ResponseEntity<>("No tasks yet",HttpStatus.NOT_FOUND);
    }
    @DeleteMapping("/delTask")
    @Transactional
    public ResponseEntity<?> delTask(@RequestParam (name="name") String name){
        // удаляем задание из БД по имени задания, если оно существует
        if(taskService.existsByName(name)){
            taskService.delTask(name);
            return new ResponseEntity<>("Task deleted",HttpStatus.OK);
        }
        return new ResponseEntity<>("No tasks yet",HttpStatus.NOT_FOUND);
    }


}
