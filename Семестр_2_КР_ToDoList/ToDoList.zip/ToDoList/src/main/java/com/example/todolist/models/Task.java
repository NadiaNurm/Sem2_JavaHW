package com.example.todolist.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

import java.util.Date;
import java.util.List;

@Entity
public class Task {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String name;
    private String about;
    @JsonIgnore
    private boolean done = false;
    private Date doneDate;
    private Date createTime;
    private Date updateTime;

    /*
    ManyToMany – многие-ко-многим
    Если параметр fetch принимает значение LAZY, то при загрузке родительской сущности, дочерняя сущность загружена не будет. Вместо нее будет создан proxy-объект.
    С помощью этого proxy-объекта Hibernate будет отслеживать обращение к этой дочерней сущности и при первом обращении загрузит ее в память.
    @JoinTable определяет таблицу и поля для связи.
    Параметр name указывает название таблицы (tasks_categories).
    Параметр joinColumns указывает на поле, которое используется для прямой связи (идентификатор task_id).
    Параметр inverseJoinColumns указывает на поле, которое используется для обратной связи (идентификатор category_id).
    Для указания столбцов связи из таблицы используется аннотация @JoinColumn.
    */
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "tasks_categories",
            joinColumns = @JoinColumn(name = "task_id"),
            inverseJoinColumns = @JoinColumn(name="category_id")
    )
    private List<Category> categoryList;

    public Task(String name, String about) {
        this.name = name;
        this.about = about;
        this.done = false;
    }
    public Task(){}

    public Task(Long id, String name, String about, boolean done, Date doneDate, Date createTime, Date updateTime, List<Category> categoryList) {
        this.id = id;
        this.name = name;
        this.about = about;
        this.done = done;
        this.doneDate = doneDate;
        this.createTime = createTime;
        this.updateTime = updateTime;
        this.categoryList = categoryList;
    }



    public void makeTask(){
        this.done = true;
    }
    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getDoneDate() {
        return doneDate;
    }

    public void setDoneDate(Date doneDate) {
        this.doneDate = doneDate;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAbout() {
        return about;
    }

    public void setAbout(String about) {
        this.about = about;
    }

    public boolean isDone() {
        return done;
    }

    public void setDone(boolean done) {
        this.done = done;
    }

    public List<Category> getCategoryList() {
        return categoryList;
    }

    public void setCategoryList(List<Category> categoryList) {
        this.categoryList = categoryList;
    }
}
