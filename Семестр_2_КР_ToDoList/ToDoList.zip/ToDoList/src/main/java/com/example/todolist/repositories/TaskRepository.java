package com.example.todolist.repositories;

import com.example.todolist.models.Task;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TaskRepository extends JpaRepository<Task,Long> {

    public boolean existsByName(String name);
    public Task findTaskByName(String name);
    public void deleteByName(String name);
}
