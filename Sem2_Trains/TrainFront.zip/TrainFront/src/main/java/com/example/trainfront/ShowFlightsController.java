package com.example.trainfront;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

public class ShowFlightsController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button mainAddFlight;

    @FXML
    private Button mainAddTrain;

    @FXML
    private TextField mainCityFrom;

    @FXML
    private TextField mainCityWhere;
    @FXML
    private TableView<FlightDAO> mainTable;
    @FXML
    private TableColumn<FlightDAO, String> mainTableArrDate;
    @FXML
    private TableColumn<FlightDAO, String> mainTableArrTime;
    @FXML
    private TableColumn<FlightDAO, Integer> mainTableAvailable;
    @FXML
    private TableColumn<FlightDAO, String> mainTableDepTime;
    @FXML
    private TableColumn<FlightDAO, String> mainTableDeparture;
    @FXML
    private TableColumn<FlightDAO, String> mainTableFrom;
    @FXML
    private TableColumn<FlightDAO, Integer> mainTableSeats;
    @FXML
    private TableColumn<FlightDAO, String> mainTableWhere;
    @FXML
    private TableColumn<FlightDAO, String> mainTableTrainName;
    @FXML
    private Button mainTrains;
    @FXML
    private ComboBox<?> todoCategory;
    private ObservableList<FlightDAO> flights = FXCollections.observableArrayList();;
    @FXML
    void initialize() throws Exception {
        addButtonToTable();
        printTable();

        mainTrains.setOnAction(x ->{
            try {
                Util.openPage("trains.fxml",mainTrains);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });

        mainAddTrain.setOnAction(x ->{
            try {
                Util.openPage("addTrain.fxml",mainAddTrain);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });

        mainAddFlight.setOnAction(x ->{
            try {
                Util.openPage("addFlight.fxml", mainAddFlight);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
    }
    private void addButtonToTable() {
        TableColumn<FlightDAO, Void> colBtn = new TableColumn("Buy ticket");
        Callback<TableColumn<FlightDAO, Void>, TableCell<FlightDAO, Void>> cellFactory = new Callback<TableColumn<FlightDAO, Void>, TableCell<FlightDAO, Void>>() {
            @Override
            public TableCell<FlightDAO, Void> call(final TableColumn<FlightDAO, Void> param) {
                final TableCell<FlightDAO, Void> cell = new TableCell<FlightDAO, Void>() {
                    private final Button btn = new Button("Buy");

                    {
                        btn.setOnAction((ActionEvent event) -> {
                            FlightDAO flightDAO = getTableView().getItems().get(getIndex());
                            String trainName = flightDAO.getTrainName();
                            try {
                                sendBuyTicket(trainName);
                                printTable();
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }
                        });
                    }
                    @Override
                    public void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            setGraphic(btn);
                        }
                    }
                };
                return cell;
            }
        };
        colBtn.setCellFactory(cellFactory);
        mainTable.getColumns().add(colBtn);
    }

    private void sendBuyTicket(String trainName) throws Exception {

        HttpPost post = new HttpPost("http://localhost:8080/buyTicket");

        // add request parameter, form parameters
        List<NameValuePair> urlParameters = new ArrayList<>();
        urlParameters.add(new BasicNameValuePair("train", trainName));

        post.setEntity(new UrlEncodedFormEntity(urlParameters));

        try (CloseableHttpClient httpClient = HttpClients.createDefault();
             CloseableHttpResponse response = httpClient.execute(post)) {
            System.out.println(EntityUtils.toString(response.getEntity()));
        }

    }

    public void printTable() throws Exception {
        flights.clear();
        upload();
        mainTableArrDate.setCellValueFactory(new PropertyValueFactory<FlightDAO, String>("arrivalDate"));
        mainTableArrTime.setCellValueFactory(new PropertyValueFactory<FlightDAO, String>("arrivalTime"));
        mainTableAvailable.setCellValueFactory(new PropertyValueFactory<FlightDAO, Integer>("availableSeats"));
        mainTableDepTime.setCellValueFactory(new PropertyValueFactory<FlightDAO, String>("departureTime"));
        mainTableDeparture.setCellValueFactory(new PropertyValueFactory<FlightDAO, String>("departureDate"));
        mainTableFrom.setCellValueFactory(new PropertyValueFactory<FlightDAO, String>("cityFrom"));
        mainTableSeats.setCellValueFactory(new PropertyValueFactory<FlightDAO, Integer>("seats"));
        mainTableWhere.setCellValueFactory(new PropertyValueFactory<FlightDAO, String>("cityWhere"));
        mainTableTrainName.setCellValueFactory(new PropertyValueFactory<FlightDAO, String>("trainName"));
        mainTable.setItems(flights);
    }
    public void upload() throws Exception {
        String jsonTrainArray = Util.sendGet("http://localhost:8080/allFlights");
        ObjectMapper objectMapper = new ObjectMapper();
        List<Flight> listFlight = objectMapper.readValue(jsonTrainArray, new TypeReference<List<Flight>>(){});
        List<FlightDAO> flightDAOList = Util.createFlightDAO(listFlight);
        flights.addAll(flightDAOList);
    }

}
