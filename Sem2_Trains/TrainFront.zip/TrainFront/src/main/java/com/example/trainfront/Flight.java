package com.example.trainfront;

import java.util.Objects;

public class Flight {
    private Long id;
    private String cityFrom;
    private String cityWhere;
    private String  departureDate;
    private String departureTime;
    private String  arrivalDate;
    private String arrivalTime;
    private int basePrice;
    private int seats;
    private Train train;

    public Flight(Long id, String cityFrom, String cityWhere, String departureDate, String departureTime, String arrivalDate, String arrivalTime, int basePrice, int seats, Train train) {
        this.id = id;
        this.cityFrom = cityFrom;
        this.cityWhere = cityWhere;
        this.departureDate = departureDate;
        this.departureTime = departureTime;
        this.arrivalDate = arrivalDate;
        this.arrivalTime = arrivalTime;
        this.basePrice = basePrice;
        this.seats = seats;
        this.train = train;
    }

    public Flight() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCityFrom() {
        return cityFrom;
    }

    public void setCityFrom(String cityFrom) {
        this.cityFrom = cityFrom;
    }

    public String getCityWhere() {
        return cityWhere;
    }

    public void setCityWhere(String cityWhere) {
        this.cityWhere = cityWhere;
    }

    public String getDepartureDate() {
        return departureDate;
    }

    public void setDepartureDate(String departureDate) {
        this.departureDate = departureDate;
    }

    public String getDepartureTime() {
        return departureTime;
    }

    public void setDepartureTime(String departureTime) {
        this.departureTime = departureTime;
    }

    public String getArrivalDate() {
        return arrivalDate;
    }

    public void setArrivalDate(String arrivalDate) {
        this.arrivalDate = arrivalDate;
    }

    public String getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(String arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public int getBasePrice() {
        return basePrice;
    }

    public void setBasePrice(int basePrice) {
        this.basePrice = basePrice;
    }

    public int getSeats() {
        return seats;
    }

    public void setSeats(int seats) {
        this.seats = seats;
    }

    public Train getTrain() {
        return train;
    }

    public void setTrain(Train train) {
        this.train = train;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Flight flight = (Flight) o;
        return basePrice == flight.basePrice && seats == flight.seats && Objects.equals(id, flight.id) && Objects.equals(cityFrom, flight.cityFrom) && Objects.equals(cityWhere, flight.cityWhere) && Objects.equals(departureDate, flight.departureDate) && Objects.equals(departureTime, flight.departureTime) && Objects.equals(arrivalDate, flight.arrivalDate) && Objects.equals(arrivalTime, flight.arrivalTime) && Objects.equals(train, flight.train);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, cityFrom, cityWhere, departureDate, departureTime, arrivalDate, arrivalTime, basePrice, seats, train);
    }

    @Override
    public String toString() {
        return "Flight{" +
                "id=" + id +
                ", cityFrom='" + cityFrom + '\'' +
                ", cityWhere='" + cityWhere + '\'' +
                ", departureDate='" + departureDate + '\'' +
                ", departureTime='" + departureTime + '\'' +
                ", arrivalDate='" + arrivalDate + '\'' +
                ", arrivalTime='" + arrivalTime + '\'' +
                ", basePrice=" + basePrice +
                ", seats=" + seats +
                ", train=" + train +
                '}';
    }
}
