package com.example.trainfront;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Util {
    public static String sendGet(String urlAddress) throws Exception {
        URL url = new URL(urlAddress);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        Scanner scanner = new Scanner(conn.getInputStream());
        String response = scanner.useDelimiter("\\A").next();
        return response;
    }

    public static List<TrainDAO> createTrainDAO(List<Train> listTrain) {
        List<TrainDAO> trainDAOList = new ArrayList<>();
        for (Train train : listTrain) {
            int seats = (int) train.getCarriages().stream().flatMap(x -> x.getFreeSeats().stream()).count();
            trainDAOList.add(new TrainDAO(train.getName(),train.getTrainType(),seats,train.getCarriages().size()));
        }
        return trainDAOList;
    }

    public static List<FlightDAO> createFlightDAO(List<Flight> listFlight) {
        List<FlightDAO> flightDAOList = new ArrayList<>();

        for (Flight f : listFlight) {
            int seats = (int) f.getTrain().getCarriages().stream().flatMap(x -> x.getFreeSeats().stream()).count();
            int availableSeats = (int) f.getTrain().getCarriages().stream().flatMap(x -> x.getFreeSeats().stream()).filter(y -> y).count();// количество true
            flightDAOList.add(new FlightDAO(f.getCityFrom(),f.getCityWhere(),f.getDepartureDate(),f.getDepartureTime(),f.getArrivalDate(),f.getArrivalTime(),f.getBasePrice(),seats,availableSeats,f.getTrain().getName()));
        }
        return flightDAOList;
    }

    public static void openPage(String s, Button button) throws IOException {
        button.getScene().getWindow().hide();
        FXMLLoader fxmlLoader=new FXMLLoader();
        URL o = Util.class.getResource(s);
        fxmlLoader.setLocation(o);
        fxmlLoader.load();//
        Parent root=fxmlLoader.getRoot();
        Stage stage=new Stage();
        stage.setScene(new Scene(root));
        stage.show();
    }



}
