package com.example.trainrest.models;

public enum TrainType {


    lastochka,sapsan,strizh,nevsky;

}
